/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import static java.lang.Class.forName;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author KARTHI RAAM
 */
@WebServlet(urlPatterns = {"/sellproduct"})
public class sellproduct extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ClassNotFoundException, SQLException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        String Email = request.getParameter("email");
        try {
            /* TODO output your page here. You may use following sample code. */
           
                String Name= request.getParameter("name");
                String url = request.getParameter("url");
                int price = Integer.parseInt(request.getParameter("price"));
                String category=request.getParameter("category");
                 Class.forName("org.apache.derby.jdbc.ClientDriver");
                Connection con = (Connection) DriverManager.getConnection("jdbc:derby://localhost:1527/emarket","acer","acer");
                PreparedStatement pst=con.prepareStatement("insert into ACER.PRODUCT values (?,?,?,?,?)");
                
                pst.setString(1, Email);
                pst.setString(2, Name);
                pst.setString(3, url);
                pst.setInt(4, price);
                pst.setString(5, category);
                
                int i = pst.executeUpdate();
                if(i==1)
                {
                    out.println("<html><body>");
                    out.println("<script type=\"text/javascript\">");
                    out.println("names = document.getElementById('uname');");
                    
                    
                    
                    out.println("window.open(\"recordsuccessfully.jsp?email="+ Email +"\", \"_parent\");");
                    out.println("</script>");
                    out.println("</body></html>");
                }
                con.close();
           
            
        }
        catch(Exception e)
        {
                    out.println("<html><body>");
                    out.println("<script type=\"text/javascript\">");
                    out.println("names = document.getElementById('uname');");
                    
                    
                    
                    out.println("window.open(\"RecordFailedPage.jsp?email="+ Email +"\", \"_parent\");");
                    out.println("</script>");
                    out.println("</body></html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(sellproduct.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(sellproduct.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(sellproduct.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(sellproduct.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
